/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pruebitaspanel;

import javax.swing.JOptionPane;

/**
 *
 * @author camig
 */
public class Matriz extends CalculatorFrame{

    /**
     * @return the filas
     */
    public int getFilas() {
        return filas;
    }

    /**
     * @param filas the filas to set
     */
    public void setFilas(int filas) {
        this.filas = filas;
    }

    /**
     * @return the columnas
     */
    public int getColumnas() {
        return columnas;
    }

    /**
     * @param columnas the columnas to set
     */
    public void setColumnas(int columnas) {
        this.columnas = columnas;
    }

    /**
     * @return the m
     */
    public double[][] getM() {
        return m;
    }

    /**
     * @param m the m to set
     */
    public void setM(double[][] m) {
        this.m = m;
    }
    private int filas;
    private int columnas;
    private double [][] m;
 
    public Matriz() {
        
    }
    
    public Matriz(int filas, int columnas){
        this.filas=filas;
        this.columnas=columnas;
        this.m = new double[filas][columnas];
        
    }
    
    public void Insertar(int filas, int columnas, int dato) {
        this.m[filas][columnas]=dato;
        
    }
    
    public String imprimir() {
        
        String s="";
        
        for(int f=0; f<this.filas; f++){
            s=s+"{ ";
            for(int c=0; c<this.columnas; c++){
            s = s + String.valueOf(m[f][c]) + "";
            }
            s=s+"}\n";
        }
        return s;
    }
    public String imprimir(double [][] matriz1) {
        
        String s="";
        
        for(int f=0; f<matriz1.length; f++){
            s=s+"[ ";
            for(int c=0; c<matriz1[0].length; c++){
                s=s+String.format("%.2f", matriz1[f][c] + " ");
            }
            s=s+"]\n";
        }
        return s;
        
    }
    public int matrizCuadrada() {
        if (this.filas==this.columnas)
            return this.filas;
        else
            return 0;
        
    }
}